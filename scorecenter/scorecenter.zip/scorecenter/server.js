var mongoClient = require('mongodb').MongoClient;
var express = require('express');
var app = express();

app.use(express.bodyParser());
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');

//Will be set upon db connection, and express app won't launch until after that
var db = null;
var collection = null;

var sanitizeRegx = /[\d\w\s\]|[\~\!\@\#\$\%\^\&\*\-\_\+]*/g; //only allow numbers, words, spaces, and
															 //standard characters -- no brackets, semicolons, parens, etc.
function sanitize(str) {
	return str.slice(0, 512).match(sanitizeRegx).join('');	 //prevent overflow from potentially massive strings?
}

//////// POST API ///
app.post('/submit.json', function(req, res) {
	if (req.body.hasOwnProperty('game_title')	//check submission format
		&& req.body.hasOwnProperty('username')
		&& req.body.hasOwnProperty('score')
		&& parseInt(req.body.score) != NaN) {
		var score = {
			game_title : sanitize(req.body.game_title),
			username : sanitize(req.body.username),
			score : parseInt(req.body.score),
			created_at : new Date()
		};

		collection.insert(score, function(err, result) {
			if (err) console.log('Error inserting a score:'); console.log(score);
		});
		res.send({success: true});
	} else {	//submission lacks necessary fields
		res.send(400, {
			error: true,
			correct_format: {
				game_title: 'title',
				username: 'your_username',
				score: 'score (an integer)'
			}
		});
	}
});

//////// GET API ///
//Enable CORS for the GET API
app.all('/highscores.json', function(req, res, next) {
 	res.header("Access-Control-Allow-Origin", "*");
 	res.header("Access-Control-Allow-Headers", "X-Requested-With");
 	next();
 });

app.get('/highscores.json', function(req, res) {
	if (req.query.game_title) {
		collection.find( { game_title : sanitize(req.query.game_title) }, {
			sort : { score : -1 },
			limit : 10,
			fields : { _id : 0 }
		} ).toArray(function(err, docs) {
			res.send(docs);
		});
	} else {
		res.send(400, 'You must request scores for a game_title!');
	}
});

//////// WEB INTERFACE ///
app.get('/usersearch', function(req, res) {
	if (req.query.username) {
		collection.find( { username : sanitize(req.query.username) }, {
			sort : { score : -1 },
			fields : { _id : 0 }
		}).toArray(function(err, docs) {
			res.render('usersearch', {
				title : 'User search',
				tableData : docs
			});
		});
	} else {
		res.render('usersearch', { title : 'User search', tableData : undefined });
	}
});

app.get('/', function(req, res) {
	collection.find( {}, { sort : { created_at : -1 }, fields : { _id : 0 }}).toArray(function(err, docs) {
		res.render('index', {
			title : 'Scores',
			tableData : docs
		});
	});
});
app.get('/style.css', function(req, res) { res.sendfile('style.css'); });

//////// DATABASE CONNECTION AND SERVER LAUNCH ///
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost:27017/scorecenter';
mongoClient.connect(mongoUri, function(err, database) {		//connect to database
	if (err) { console.log('Error connecting to database at ' + mongoUri); return; }
	console.log('Connected to database at ' + mongoUri);
	db = database;
	db.collection('scores', function(err, col) {			//open collection
		if (err) { console.log('Error opening collection "scores"'); return; }
		collection = col;
		collection.ensureIndex({ game : 1 }, function(err, indexName) {		//index by 'game' to improve performance of GET-by-game api
			if (err) { console.log('Unable to create index for ' + indexName); return }
		});
		collection.ensureIndex({ created_at : 1 }, function(err, indexName) {		//index by 'created_at' to improve performance of homepage display
			if (err) { console.log('Unable to create index for ' + indexName); return }
		});
		var port = process.env.PORT || 5000;
		app.listen(port, function() {						//run express app
		    console.log('Scorecenter started on port ' + port);
		    });
	});
});