# SCORECENTER
Gabe Joseph
*******************
An API for storing and retrieving high scores from HTML5 games. Or, really, for storing whatever you want...

Created with node.js, express, and Mongo.

1. All aspects have been implemented correctly.
2. I collaborated with nobody besides the internet.
3. I spent about 12 hours on this project.